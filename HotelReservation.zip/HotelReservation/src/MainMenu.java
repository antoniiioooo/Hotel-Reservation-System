import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MainMenu extends JFrame implements ActionListener
{
    JButton customerButton = new JButton();
    JButton managerButton = new JButton();

    MainMenu()
    {
        // Customer Button
        customerButton.setBounds(250, 175, 500, 150);
        customerButton.setText("I am a Customer");
        customerButton.setFocusable(false);
        customerButton.addActionListener(this);

        // Manager Button
        managerButton.setBounds(250, 400, 500, 150);
        managerButton.setText("I am a Manager");
        managerButton.setFocusable(false);
        managerButton.addActionListener(this);

        // Main Menu Title
        JLabel menuTitle = new JLabel();
        menuTitle.setText("Welcome to the Hotel Reservation System!");
        menuTitle.setFont(new Font("MV Boli", Font.BOLD, 30));
        menuTitle.setBounds(160, 50, 700, 50);

        // Making the default frame properties
        this.setSize(1000, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setLayout(null);
        this.setTitle("Hotel Reservation System (Matador Technologies TM)");
        this.setResizable(false);

        // Adding the components to the menu frame
        this.add(menuTitle);
        this.add(customerButton);
        this.add(managerButton);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==customerButton)
        {
            System.out.println("This customer button will go to the room search menu");
        }
        if (e.getSource()==managerButton)
        {
            System.out.println("This manager button will go the the admin access screen");
        }
    }

}
